Les tests purement Java du parseur couvrent les nombres de 1 a 90,
les repetitions identiques et le rejet de paroles non numeriques.
Le moteur de reconnaissance acoustique doit encore etre teste sur tablette.
