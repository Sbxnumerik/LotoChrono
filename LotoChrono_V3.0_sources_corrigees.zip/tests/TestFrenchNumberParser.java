import fr.lotochrono.FrenchNumberParser;

public class TestFrenchNumberParser {
    static void expect(String utterance, int expected) {
        int got = FrenchNumberParser.parse(utterance);
        if (got != expected) {
            throw new AssertionError("Pour '" + utterance + "', attendu " + expected + ", obtenu " + got);
        }
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 90; i++) {
            expect(FrenchNumberParser.spell(i), i);
            expect(String.valueOf(i), i);
            expect("Le " + FrenchNumberParser.spell(i), i);
            expect(FrenchNumberParser.spell(i) + " !", i);
            expect(FrenchNumberParser.spell(i) + " " + FrenchNumberParser.spell(i), i);
        }
        expect("Quarante-deux", 42);
        expect("LE NUMÉRO QUARANTE-DEUX", 42);
        expect("Quarante deux, le quarante deux", 42);
        expect("Soixante-dix", 70);
        expect("Soixante et onze", 71);
        expect("Soixante onze", 71);
        expect("Quatre-vingts", 80);
        expect("Quatre-vingt", 80);
        expect("Quatre-vingt et un", 81);
        expect("Quatre-vingt-dix", 90);
        expect("4 et 2", -1);
        expect("Le cinquante trois puis le vingt huit", -1);
        expect("Le public parle", -1);
        expect("", -1);
        expect("quatre vingt onze", -1);
        expect("quatre vingt deux quatre vingt trois", -1);
        expect("cent", -1);
        expect("zero", -1);
        System.out.println("OK - tests de nombres de 1 a 90 et repetitions reussis");
    }
}
