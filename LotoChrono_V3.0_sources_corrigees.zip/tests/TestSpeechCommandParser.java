import fr.lotochrono.SpeechCommandParser;

public class TestSpeechCommandParser {
    public static void main(String[] args) {
        for (String phrase : new String[]{
                "GAGNANT", "On a un gagnant !", "C'est gagnant", "Une gagnante", "gagnant, gagnant"}) {
            if (!SpeechCommandParser.isWinnerCommand(phrase)) {
                throw new AssertionError("Commande de pause non reconnue : " + phrase);
            }
        }
        for (String phrase : new String[]{
                "", "quarante deux", "j'ai deux cartons", "gagnants", "un gagne", "regagnant"}) {
            if (SpeechCommandParser.isWinnerCommand(phrase)) {
                throw new AssertionError("Fausse commande de pause : " + phrase);
            }
        }
        System.out.println("TestSpeechCommandParser: OK");
    }
}
