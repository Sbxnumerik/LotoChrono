import fr.lotochrono.SpeechCommandParser;
public class TestWinnerCommandsV12 {
 public static void main(String[] args) {
  String[] winners={"Gagnant", "Gagnante", "On a un gagnant"};
  String[] cancellations={"Il s'est trompé", "Elle s'est trompée", "C'est une erreur"};
  for(String s:winners) if(!SpeechCommandParser.isWinnerCommand(s) || SpeechCommandParser.isFalseWinnerCommand(s)) throw new AssertionError(s);
  for(String s:cancellations) if(!SpeechCommandParser.isFalseWinnerCommand(s) || SpeechCommandParser.isWinnerCommand(s)) throw new AssertionError(s);
  for(String s:new String[]{"gagnants", "regagnant", "quarante deux"}) if(SpeechCommandParser.isWinnerCommand(s) || SpeechCommandParser.isFalseWinnerCommand(s)) throw new AssertionError(s);
  System.out.println("Commandes gagnant et annulation V1.2 : OK");
 }
}
