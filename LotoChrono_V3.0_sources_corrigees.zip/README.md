# Loto Chrono — Android (V1.1 bêta)

Application native Android (tablettes Samsung et Xiaomi) conçue pour un boulier de loto associatif. **L'APK ne nécessite ni Wi‑Fi ni 4G pendant l'utilisation** : l'app n'a volontairement **pas la permission INTERNET**. Le moteur Vosk et le modèle de langue française sont incorporés à l'APK lors de sa fabrication.

## Fonctionnalités V1.1

- Reconnaissance vocale française continue (nombres de 1 à 90) par le micro de la tablette ; aucune validation manuelle pour les numéros reconnus.
- Ignore les répétitions d'un numéro déjà annoncé pendant la partie : **aucune remise à zéro du timer**.
- Chronomètre **15 → 0 secondes**, rouge durant le décompte puis vert à 0.
- Liste déroulante de **1 à 60 secondes**, pas de 1 seconde, valeur par défaut 15 secondes. Ce seul réglage est mémorisé.
- Si un nouveau numéro différent arrive avant la fin du timer : **flash visuel rouge, sans signal sonore**, puis timer réinitialisé.
- Numéro courant en très grand à gauche ; chronomètre à droite ; 5 derniers numéros sous ces panneaux.
- Portrait et paysage ; écran maintenu allumé dans l'application.
- Bouton **Corriger** pour remplacer manuellement le dernier numéro (sans réinitialiser le chrono), ou **Ajouter** un numéro manuellement si le micro en a manqué un.
- **Commande vocale « gagnant »** : l'application met automatiquement le tirage en pause et coupe son écoute. Elle accepte aussi « on a un gagnant » et « gagnante ». Aucun numéro prononcé avec ce mot-clé n'est ajouté. Le traitement attend une transcription finale (court silence).
- **Bouton PAUSE / REPRENDRE** permanent : une pause manuelle est également possible. Le compte à rebours est gelé, et la reconnaissance est interrompue jusqu'à l'appui sur **REPRENDRE**. Aucun son.
- Bouton **Nouveau** : confirmation puis remise à zéro de la partie.
- Aucun verrouillage des commandes, aucune projection vers un deuxième écran.
- Aucun historique de parties enregistré ; uniquement les numéros en cours en mémoire vive, indispensables pour empêcher les doublons et afficher les 5 derniers.
- Aucun enregistrement ni envoi de voix.

## Limites et mise en garde

**V1 bêta non testée en salle** : la reconnaissance automatique de la voix dans un loto peut se tromper à cause du public, de l'écho de la sonorisation et des annonces superposées. La transcription n'est validée qu'en fin de groupe de parole (court silence), ce qui peut décaler de quelques centaines de millisecondes le début du décompte. Testez impérativement la tablette à côté du haut-parleur (ou avec un micro compatible connecté) avant un loto réel. Le micro de la sono **n'est pas automatiquement relié** au micro de la tablette.

Le mot « gagnant » peut aussi être prononcé par un spectateur : cette commande vocale peut donc provoquer une pause involontaire. Appuyer sur **REPRENDRE** suffit à relancer l'écoute. La reprise n'est pas vocale puisque le microphone est arrêté pendant la pause.

Un spectateur qui prononce clairement un nombre à proximité de la tablette peut toujours provoquer un faux positif. Sans confirmation et sans source audio isolée, aucun logiciel ne peut garantir 100 % de justesse.

## Comment générer l'APK sans installer Python

### Option A — GitHub Actions (dans le cloud)

1. Créer un dépôt GitHub (privé possible), puis y copier **les fichiers extraits du ZIP**. Le dossier `.github/workflows/` doit être présent, avec le fichier `build-apk.yml`.
2. Aller dans l'onglet **Actions** du dépôt.
3. Ouvrir **Compiler Loto Chrono APK** puis cliquer sur **Run workflow** (ou attendre le lancement automatique après l'ajout des fichiers sur `main`).
4. Le service compile automatiquement l'APK, et télécharge une seule fois le modèle français Vosk pendant **la fabrication**.
5. À la fin, ouvrir l'exécution terminée et télécharger l'artifact **LotoChrono-v1.1-APK**. Décompresser l'archive obtenue et récupérer `app-debug.apk`.
6. Copier le fichier APK sur la tablette Xiaomi ou Samsung, autoriser l'installation depuis cette source dans les paramètres Android si demandé, puis ouvrir l'application. Autoriser l'accès au microphone.
7. Le **premier lancement** peut prendre du temps : le modèle vocal embarqué est décompressé localement. Ensuite l'application fonctionne entièrement hors ligne.

> Si le dépôt GitHub impose des restrictions d'Actions, il faut autoriser les workflows dans les paramètres du dépôt. L'exécution utilise Internet pour télécharger les outils et le modèle **seulement pendant la compilation**, pas sur la tablette.

### Option B — Android Studio sur Windows/macOS/Linux

1. Installer une version d'Android Studio prenant en charge Android Gradle Plugin **8.9.2**, Gradle **8.11.1** et le SDK Android 35.
2. Ouvrir le dossier racine du projet `LotoChrono_Android_Project` avec Android Studio.
3. Configurer Gradle 8.11.1 si Android Studio le demande et laisser la synchronisation récupérer les dépendances.
4. Menu **Build → Build APK(s)**. La tâche Gradle `prepareOfflineModel` télécharge automatiquement le petit modèle français **vosk-model-small-fr-0.22** (environ 40 Mo) avant la création de l'APK.
5. APK attendu : `app/build/outputs/apk/debug/app-debug.apk`.

**Ne pas chercher le fichier APK dans ce ZIP** : c'est le **projet source** complet. L'APK doit être compilé par un environnement Android (Android Studio ou workflow Github). Le fichier debug est signé pour l'installation de test, il ne doit pas être distribué comme une version commerciale validée.

## Technique

- Java 17 / Android SDK 35 / API minimum 24.
- Gradle AGP 8.9.2 / Gradle 8.11.1.
- `com.alphacephei:vosk-android:0.3.75` (Apache-2.0).
- Modèle `vosk-model-small-fr-0.22` ; téléchargement officiel lors du build : https://alphacephei.com/vosk/models
- Aucune permission INTERNET dans le manifeste ; `RECORD_AUDIO` uniquement.
- `FrenchNumberParser` : formes françaises 1..90, répétitions identiques, filtre conservateur des phrases. `SpeechCommandParser` : reconnaissance du mot-clé « gagnant » sans interpréter les nombres.

### Vérifier le parseur (facultatif)

Dans un terminal Java 17 (pas besoin d'Android Studio) :

```bash
mkdir -p /tmp/loto-classes
javac -d /tmp/loto-classes app/src/main/java/fr/lotochrono/FrenchNumberParser.java app/src/main/java/fr/lotochrono/SpeechCommandParser.java tests/TestFrenchNumberParser.java tests/TestSpeechCommandParser.java
java -cp /tmp/loto-classes TestFrenchNumberParser
java -cp /tmp/loto-classes TestSpeechCommandParser
```

Ces tests vérifient la reconnaissance textuelle des nombres 1 à 90, les répétitions, les rejets et le mot-clé « gagnant ». Ils **ne testent pas** la performance acoustique du modèle.

## Choix de la version V1.1

- Mise en pause automatique sur le mot « gagnant » ; reprise par bouton uniquement.
- Pas de verrouillage des commandes.
- Pas de projection sur un deuxième écran.
- Pas de reprise après extinction, conformément au souhait de ne conserver aucun historique de parties.

## Sources et licences

- Bibliothèque Vosk : https://github.com/alphacep/vosk-api (Apache-2.0)
- Modèles de langue Vosk : https://alphacephei.com/vosk/models
- Documentation Android : https://developer.android.com/build/building-cmdline

Projet de démonstration, à tester en conditions réelles avant une utilisation publique.
