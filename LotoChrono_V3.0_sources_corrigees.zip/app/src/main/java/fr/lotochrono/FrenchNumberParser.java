package fr.lotochrono;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Parseur conservateur pour les numeros de loto (1 a 90).
 * Ne cherche pas de nombres a l'interieur de conversations quelconques :
 * la phrase doit essentiellement etre un nombre, eventuellement repete.
 */
public final class FrenchNumberParser {
    private static final String[] BELOW_17 = {
        "zero", "un", "deux", "trois", "quatre", "cinq", "six", "sept",
        "huit", "neuf", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize"
    };
    private static final Map<String, Integer> FORMS = new HashMap<>();
    private static final List<String> ORDERED = new ArrayList<>();

    static {
        for (int n = 1; n <= 90; n++) {
            register(String.valueOf(n), n);
            String form = spell(n);
            register(form, n);
            if (form.contains(" et ")) {
                register(form.replace(" et ", " "), n);
            }
            if (n == 80) {
                register("quatre vingt", 80);
            }
            if (n == 81) {
                register("quatre vingt et un", 81);
            }
        }
        ORDERED.addAll(FORMS.keySet());
        ORDERED.sort(Comparator.comparingInt(String::length).reversed());
    }

    private FrenchNumberParser() { }

    private static void register(String s, int value) {
        FORMS.put(normalize(s), value);
    }

    public static String spell(int n) {
        if (n < 1 || n > 90) {
            throw new IllegalArgumentException("Numero hors de la plage 1..90 : " + n);
        }
        if (n <= 16) return BELOW_17[n];
        if (n < 20) return "dix " + BELOW_17[n - 10];
        if (n < 70) {
            int ten = n / 10 * 10;
            int unit = n - ten;
            String base;
            switch (ten) {
                case 20: base = "vingt"; break;
                case 30: base = "trente"; break;
                case 40: base = "quarante"; break;
                case 50: base = "cinquante"; break;
                default: base = "soixante"; break;
            }
            if (unit == 0) return base;
            if (unit == 1) return base + " et un";
            return base + " " + BELOW_17[unit];
        }
        if (n < 80) {
            if (n == 71) return "soixante et onze";
            return "soixante " + spell(n - 60);
        }
        if (n == 80) return "quatre vingts";
        return "quatre vingt " + spell(n - 80);
    }

    /** Retourne -1 lorsque la phrase ne designe pas clairement un seul numero. */
    public static int parse(String rawTranscript) {
        if (rawTranscript == null) return -1;
        String text = stripIntro(normalize(rawTranscript));
        Integer exact = FORMS.get(text);
        if (exact != null) return exact;

        // Le boulier peut repeter exactement le numero dans une meme phrase.
        // On autorise 2 ou 3 annonces identiques, jamais 2 numeros differents.
        for (String form : ORDERED) {
            if (!text.startsWith(form + " ")) continue;
            String rest = text;
            int occurrences = 0;
            while (occurrences < 3) {
                rest = stripIntro(rest);
                if (rest.equals(form)) {
                    occurrences++;
                    rest = "";
                    break;
                }
                if (rest.startsWith(form + " ")) {
                    occurrences++;
                    rest = rest.substring(form.length()).trim();
                } else {
                    break;
                }
            }
            if (occurrences >= 2 && rest.isEmpty()) return FORMS.get(form);
        }
        return -1;
    }

    private static String stripIntro(String text) {
        String value = text;
        for (int i = 0; i < 7; i++) {
            String old = value;
            String[] prefixes = {
                "le numero ", "la boule ", "numero ", "boule ",
                "j annonce ", "c est ", "voici ", "on a ", "le ", "la "
            };
            for (String prefix : prefixes) {
                if (value.startsWith(prefix)) {
                    value = value.substring(prefix.length()).trim();
                    break;
                }
            }
            if (old.equals(value)) break;
        }
        return value;
    }

    public static String normalize(String s) {
        String noAccents = Normalizer.normalize(s.toLowerCase(Locale.FRANCE),
                Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return noAccents.replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
    }
}
