package fr.lotochrono;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SeekBar;
import android.widget.ProgressBar;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.AudioFormat;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Loto Chrono - prototype Android hors ligne.
 * Aucun historique n'est sauvegarde entre les sessions, seul le timer l'est.
 */
public class MainActivity extends Activity implements RecognitionListener {
    private static final int RECORD_PERMISSION_REQUEST = 40;
    private static final int MIN_SECONDS = 1;
    private static final int MAX_SECONDS = 60;

    private static final int BG = Color.rgb(15, 23, 42);
    private static final int PANEL = Color.rgb(30, 58, 95);
    private static final int RED = Color.rgb(153, 27, 27);
    private static final int GREEN = Color.rgb(21, 128, 61);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(191, 219, 254);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService modelLoader = Executors.newSingleThreadExecutor();
    private final List<Integer> currentDraw = new ArrayList<>();
    private final Set<Integer> announced = new HashSet<>();

    private FrameLayout screen;
    private View redFlash;
    private TextView numberText;
    private TextView timerText;
    private TextView timerHintText;
    private TextView statusText;
    private TextView ballsCountText;
    private Button pauseButton;
    private LinearLayout lastFiveRow;
    private LinearLayout timerPanel;
    private FrameLayout winnerOverlay;
    private ProgressBar micLevel;
    private int sensitivity = 70;
    private boolean winnerShown = false;
    private long lastVoiceCommandAt = 0;

    private int selectedSeconds = 15;
    private long lastNumberAt = -1L;
    private long pauseStartedAt = -1L;
    private boolean paused = false;
    private Model model;
    private AudioRecord audioRecord;
    private Thread microphoneThread;
    private volatile boolean listening = false;
    private Recognizer activeRecognizer;
    private boolean modelLoading = false;
    private boolean foreground = false;
    private boolean destroyed = false;
    private Boolean lastTimerGreen = null;

    private final Runnable timerTicker = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            renderTimer();
            handler.postDelayed(this, 80);
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemBars();
        selectedSeconds = getPreferences(Context.MODE_PRIVATE).getInt("timer_seconds", 15);
        sensitivity = getPreferences(Context.MODE_PRIVATE).getInt("mic_sensitivity", 70);
        if (selectedSeconds < MIN_SECONDS || selectedSeconds > MAX_SECONDS) {
            selectedSeconds = 15;
        }
        buildScreen();
        handler.post(timerTicker);
        checkMicrophonePermission();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        buildScreen();
        renderScreen();
    }

    private void buildScreen() {
        boolean landscape = getResources().getConfiguration().orientation
            == Configuration.ORIENTATION_LANDSCAPE;

        lastTimerGreen = null;
        screen = new FrameLayout(this);
        screen.setBackgroundColor(BG);
        setContentView(screen);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(landscape ? 20 : 14), dp(12), dp(landscape ? 20 : 14), dp(14));
        screen.addView(content, new FrameLayout.LayoutParams(-1, -1));

        // Barre du haut : etat du micro + choix de la duree.
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        content.addView(header, new LinearLayout.LayoutParams(-1, dp(58)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView title = label("LOTO CHRONO", landscape ? 22 : 18, WHITE, true);
        brand.addView(title);
        statusText = label("CHARGEMENT DU MICRO...", 11, Color.rgb(134, 239, 172), true);
        brand.addView(statusText);

        TextView durationLabel = label("DURÉE  ", 12, WHITE, true);
        header.addView(durationLabel);
        Spinner durationSpinner = new Spinner(this);
        ArrayList<String> options = new ArrayList<>();
        for (int s = MIN_SECONDS; s <= MAX_SECONDS; s++) options.add(s + " s");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
            android.R.layout.simple_spinner_item, options) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                return spinnerText(position, false);
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                return spinnerText(position, true);
            }
            private View spinnerText(int position, boolean dropdown) {
                TextView view = label(getItem(position), 16,
                    dropdown ? Color.BLACK : WHITE, true);
                view.setPadding(dp(12), dp(11), dp(12), dp(11));
                return view;
            }
        };
        durationSpinner.setAdapter(adapter);
        durationSpinner.setBackground(rounded(Color.rgb(30, 41, 59), 12));
        durationSpinner.setMinimumWidth(dp(80));
        durationSpinner.setSelection(selectedSeconds - MIN_SECONDS);
        durationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int value = position + MIN_SECONDS;
                if (selectedSeconds != value) {
                    selectedSeconds = value;
                    getPreferences(Context.MODE_PRIVATE).edit()
                        .putInt("timer_seconds", value).apply();
                    renderTimer();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        header.addView(durationSpinner,
            new LinearLayout.LayoutParams(dp(90), dp(52)));

        LinearLayout microphoneControls = new LinearLayout(this);
        microphoneControls.setOrientation(LinearLayout.VERTICAL);
        microphoneControls.setPadding(dp(8), dp(3), dp(8), dp(3));
        content.addView(microphoneControls, new LinearLayout.LayoutParams(-1, dp(92)));
        TextView sensitivityLabel = label("Sensibilité du microphone : " + sensitivity + "%", 13, WHITE, true);
        sensitivityLabel.setGravity(Gravity.CENTER);
        microphoneControls.addView(sensitivityLabel);
        SeekBar sensitivityBar = new SeekBar(this);
        sensitivityBar.setMax(100);
        sensitivityBar.setProgress(sensitivity);
        microphoneControls.addView(sensitivityBar, new LinearLayout.LayoutParams(-1, dp(32)));
        sensitivityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                sensitivity = progress;
                sensitivityLabel.setText("Sensibilité du microphone : " + sensitivity + "%");
                if (fromUser) getPreferences(Context.MODE_PRIVATE).edit().putInt("mic_sensitivity", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        microphoneControls.addView(label("Niveau sonore reçu par le micro", 11, MUTED, false));
        micLevel = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        micLevel.setMax(100);
        microphoneControls.addView(micLevel, new LinearLayout.LayoutParams(-1, dp(12)));

        // Partie centrale toujours cote a cote, meme en portrait.
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams centerParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        centerParams.setMargins(0, dp(10), 0, dp(12));
        content.addView(center, centerParams);

        LinearLayout numberPanel = new LinearLayout(this);
        numberPanel.setOrientation(LinearLayout.VERTICAL);
        numberPanel.setGravity(Gravity.CENTER);
        numberPanel.setBackground(rounded(PANEL, 20));
        LinearLayout.LayoutParams halfLeft = new LinearLayout.LayoutParams(0, -1, 1f);
        halfLeft.setMargins(0, 0, dp(7), 0);
        center.addView(numberPanel, halfLeft);
        numberPanel.addView(label("NUMÉRO ANNONCÉ", landscape ? 17 : 11, MUTED, true));
        numberText = label("—", landscape ? 150 : 103, WHITE, true);
        numberText.setGravity(Gravity.CENTER);
        numberText.setIncludeFontPadding(false);
        numberText.setSingleLine(true);
        numberPanel.addView(numberText);

        timerPanel = new LinearLayout(this);
        timerPanel.setOrientation(LinearLayout.VERTICAL);
        timerPanel.setGravity(Gravity.CENTER);
        timerPanel.setBackground(rounded(RED, 20));
        LinearLayout.LayoutParams halfRight = new LinearLayout.LayoutParams(0, -1, 1f);
        halfRight.setMargins(dp(7), 0, 0, 0);
        center.addView(timerPanel, halfRight);
        timerPanel.addView(label("CHRONOMÈTRE", landscape ? 17 : 11,
            Color.rgb(254, 202, 202), true));
        timerText = label("00:15", landscape ? 94 : 55, WHITE, true);
        timerText.setGravity(Gravity.CENTER);
        timerText.setIncludeFontPadding(false);
        timerText.setSingleLine(true);
        timerPanel.addView(timerText);
        timerHintText = label("Attente du premier numéro", landscape ? 14 : 11,
            Color.rgb(254, 202, 202), false);
        timerHintText.setGravity(Gravity.CENTER);
        timerPanel.addView(timerHintText);

        TextView lastLabel = label("5 DERNIERS NUMÉROS", landscape ? 14 : 12,
            Color.rgb(203, 213, 225), true);
        LinearLayout.LayoutParams lastTitleParams = new LinearLayout.LayoutParams(-1, dp(26));
        content.addView(lastLabel, lastTitleParams);
        lastFiveRow = new LinearLayout(this);
        lastFiveRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lastRowParams = new LinearLayout.LayoutParams(-1, dp(landscape ? 62 : 58));
        content.addView(lastFiveRow, lastRowParams);

        // La pause doit rester facilement accessible, y compris sur un petit ecran portrait.
        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams footerParams = new LinearLayout.LayoutParams(-1,
            dp(landscape ? 68 : 116));
        footerParams.setMargins(0, dp(8), 0, 0);
        content.addView(footer, footerParams);

        ballsCountText = label("0 BOULE ANNONCÉE", landscape ? 14 : 12,
            Color.rgb(203, 213, 225), true);
        Button correctButton = actionButton("CORRIGER", Color.rgb(30, 64, 175));
        correctButton.setOnClickListener(v -> showCorrectionDialog());
        Button resetButton = actionButton("NOUVELLE PARTIE", Color.rgb(55, 65, 81));
        resetButton.setOnClickListener(v -> confirmNewDraw());
        pauseButton = actionButton("PAUSE", Color.rgb(180, 83, 9));
        pauseButton.setOnClickListener(v -> setPaused(!paused));

        if (landscape) {
            footer.addView(ballsCountText, new LinearLayout.LayoutParams(0, -2, 1f));
            LinearLayout.LayoutParams pauseParams =
                new LinearLayout.LayoutParams(dp(142), dp(54));
            pauseParams.setMargins(dp(8), 0, 0, 0);
            footer.addView(pauseButton, pauseParams);
            LinearLayout.LayoutParams correctParams =
                new LinearLayout.LayoutParams(dp(132), dp(54));
            correctParams.setMargins(dp(8), 0, 0, 0);
            footer.addView(correctButton, correctParams);
            LinearLayout.LayoutParams resetParams =
                new LinearLayout.LayoutParams(dp(158), dp(54));
            resetParams.setMargins(dp(8), 0, 0, 0);
            footer.addView(resetButton, resetParams);
        } else {
            LinearLayout topButtons = new LinearLayout(this);
            topButtons.setOrientation(LinearLayout.HORIZONTAL);
            topButtons.setGravity(Gravity.CENTER_VERTICAL);
            footer.addView(topButtons, new LinearLayout.LayoutParams(-1, dp(52)));
            topButtons.addView(ballsCountText, new LinearLayout.LayoutParams(0, -2, 1f));
            topButtons.addView(pauseButton, new LinearLayout.LayoutParams(dp(140), dp(48)));

            LinearLayout bottomButtons = new LinearLayout(this);
            bottomButtons.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams bottomParams = new LinearLayout.LayoutParams(-1, dp(54));
            bottomParams.setMargins(0, dp(6), 0, 0);
            footer.addView(bottomButtons, bottomParams);
            LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, -1, 1f);
            half.setMargins(0, 0, dp(5), 0);
            bottomButtons.addView(correctButton, half);
            LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, -1, 1f);
            half2.setMargins(dp(5), 0, 0, 0);
            bottomButtons.addView(resetButton, half2);
        }

        // Flash rouge sans aucune sortie audio.
        redFlash = new View(this);
        redFlash.setBackgroundColor(Color.rgb(255, 0, 0));
        redFlash.setAlpha(0f);
        redFlash.setClickable(false);
        screen.addView(redFlash, new FrameLayout.LayoutParams(-1, -1));
        winnerOverlay = new FrameLayout(this);
        winnerOverlay.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(68, 0, 0), Color.rgb(180, 14, 14), Color.rgb(90, 0, 0)}));
        LinearLayout winnerContent = new LinearLayout(this);
        winnerContent.setOrientation(LinearLayout.VERTICAL);
        winnerContent.setGravity(Gravity.CENTER);
        TextView winnerTitle = label("🏆 GAGNANT !", landscape ? 80 : 46, Color.rgb(255, 215, 40), true);
        winnerTitle.setGravity(Gravity.CENTER);
        winnerContent.addView(winnerTitle);
        TextView winnerNumber = label("—", landscape ? 126 : 100, WHITE, true);
        winnerNumber.setGravity(Gravity.CENTER);
        winnerNumber.setTag("winnerNumber");
        winnerContent.addView(winnerNumber);
        TextView winnerHint = label("Touchez l'écran pour une nouvelle partie", landscape ? 25 : 18, WHITE, true);
        winnerHint.setGravity(Gravity.CENTER);
        winnerContent.addView(winnerHint);
        winnerOverlay.addView(winnerContent, new FrameLayout.LayoutParams(-1, -1));
        winnerOverlay.setOnClickListener(v -> startNewDraw());
        screen.addView(winnerOverlay, new FrameLayout.LayoutParams(-1, -1));
        renderScreen();
    }

    private Button actionButton(String text, int bg) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(WHITE);
        button.setPadding(dp(6), 0, dp(6), 0);
        button.setBackground(rounded(bg, 14));
        return button;
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(s);
        view.setTextColor(color);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(float units) {
        return (int) (getResources().getDisplayMetrics().density * units + .5f);
    }

    private void renderScreen() {
        if (numberText == null) return;
        if (winnerOverlay != null) {
            winnerOverlay.setVisibility(winnerShown ? View.VISIBLE : View.GONE);
            if (winnerShown) {
                View numberView = winnerOverlay.findViewWithTag("winnerNumber");
                if (numberView instanceof TextView) ((TextView) numberView).setText(
                    currentDraw.isEmpty() ? "—" : String.valueOf(currentDraw.get(currentDraw.size()-1)));
            }
        }
        if (currentDraw.isEmpty()) {
            numberText.setText("—");
        } else {
            numberText.setText(String.valueOf(currentDraw.get(currentDraw.size() - 1)));
        }
        if (ballsCountText != null) {
            int count = currentDraw.size();
            ballsCountText.setText(count + (count == 1 ? " BOULE ANNONCÉE" : " BOULES ANNONCÉES"));
        }
        if (lastFiveRow != null) {
            lastFiveRow.removeAllViews();
            int start = Math.max(0, currentDraw.size() - 5);
            ArrayList<Integer> five = new ArrayList<>(currentDraw.subList(start, currentDraw.size()));
            for (int i = 0; i < 5; i++) {
                String number = i < 5 - five.size() ? "—" : String.valueOf(five.get(i - (5 - five.size())));
                boolean mostRecent = i == 4 && !five.isEmpty();
                TextView chip = label(number, 22, WHITE, true);
                chip.setGravity(Gravity.CENTER);
                chip.setBackground(rounded(mostRecent ? Color.rgb(37, 99, 235)
                    : Color.rgb(51, 65, 85), 11));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
                p.setMargins(dp(3), dp(2), dp(3), dp(2));
                lastFiveRow.addView(chip, p);
            }
        }
        if (pauseButton != null) {
            pauseButton.setText(paused ? "REPRENDRE" : "PAUSE");
            pauseButton.setBackground(rounded(paused ? GREEN : Color.rgb(180, 83, 9), 14));
        }
        renderTimer();
        renderStatus();
    }

    private long remainingMillis() {
        if (lastNumberAt < 0) return selectedSeconds * 1000L;
        long currentTime = paused ? pauseStartedAt : SystemClock.elapsedRealtime();
        long elapsed = currentTime - lastNumberAt;
        return Math.max(0L, selectedSeconds * 1000L - elapsed);
    }

    private void renderTimer() {
        if (timerText == null || timerPanel == null) return;
        long millis = remainingMillis();
        int remainingSeconds = (int) Math.ceil(millis / 1000.0);
        timerText.setText(String.format(Locale.FRANCE, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60));
        boolean ready = lastNumberAt >= 0 && millis == 0;
        if (lastTimerGreen == null || lastTimerGreen != ready) {
            timerPanel.setBackground(rounded(ready ? GREEN : RED, 20));
            lastTimerGreen = ready;
        }
        if (timerHintText != null) {
            timerHintText.setText(paused ? "PAUSE · APPUYER SUR REPRENDRE" :
                (ready ? "PRÊT POUR LE SUIVANT" :
                (lastNumberAt < 0 ? "EN ATTENTE DU 1er NUMÉRO" : "NE PAS ACCÉLÉRER")));
        }
    }

    private void flashTooFast() {
        if (redFlash == null) return;
        redFlash.animate().cancel();
        ObjectAnimator animation = ObjectAnimator.ofFloat(redFlash, View.ALPHA,
            0f, .68f, .0f, .68f, .0f);
        animation.setDuration(700);
        animation.start();
    }

    /** Met le chrono en pause et coupe le micro jusqu'a une reprise manuelle. */
    private void setPaused(boolean nextPaused) {
        if (paused == nextPaused) return;
        long now = SystemClock.elapsedRealtime();
        if (nextPaused) {
            pauseStartedAt = now;
            paused = true;
            // Le micro reste actif pendant une pause.
        } else {
            if (lastNumberAt >= 0 && pauseStartedAt >= 0) {
                // Le temps passe en pause ne doit pas etre decompte.
                lastNumberAt += now - pauseStartedAt;
            }
            pauseStartedAt = -1L;
            paused = false;
        }
        renderScreen();
    }

    private void acceptRecognizedNumber(int number, boolean fromMicrophone) {
        if (number < 1 || number > 90) return;
        if (announced.contains(number)) {
            // Les repetitions vocales ne relancent JAMAIS le chrono.
            return;
        }
        boolean tooFast = fromMicrophone && lastNumberAt >= 0 && remainingMillis() > 0;
        announced.add(number);
        currentDraw.add(number);
        lastNumberAt = SystemClock.elapsedRealtime();
        // Si un numero est ajoute manuellement durant la pause, le timer reste gele.
        if (paused) pauseStartedAt = lastNumberAt;
        renderScreen();
        if (tooFast) flashTooFast();
    }

    private void showCorrectionDialog() {
        final int last = currentDraw.isEmpty() ? -1 : currentDraw.get(currentDraw.size() - 1);
        EditText entry = new EditText(this);
        entry.setInputType(InputType.TYPE_CLASS_NUMBER);
        entry.setSingleLine(true);
        if (last > 0) entry.setText(String.valueOf(last));
        entry.setSelectAllOnFocus(true);
        entry.setTextSize(28);
        entry.setGravity(Gravity.CENTER);
        LinearLayout frame = new LinearLayout(this);
        frame.setPadding(dp(26), dp(8), dp(26), dp(2));
        frame.addView(entry, new LinearLayout.LayoutParams(-1, dp(60)));
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Saisir ou corriger un numéro")
            .setMessage("Remplacer corrige le dernier numéro sans relancer le chrono. Ajouter sert en dépannage si le micro n'a rien entendu.")
            .setView(frame)
            .setNegativeButton("Annuler", null)
            .setNeutralButton("Ajouter", null)
            .setPositiveButton("Remplacer", null)
            .create();
        dialog.setOnShowListener(d -> {
            if (last < 0) dialog.getButton(AlertDialog.BUTTON_POSITIVE).setVisibility(View.GONE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                int next = readEnteredNumber(entry);
                if (next < 0) return;
                if (currentDraw.isEmpty() || currentDraw.get(currentDraw.size() - 1) != last) {
                    Toast.makeText(this, "Un autre numéro a été reconnu : réouvre la correction.",
                        Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                    return;
                }
                if (next != last && announced.contains(next)) {
                    entry.setError("Ce numéro a déjà été annoncé.");
                    return;
                }
                announced.remove(last);
                announced.add(next);
                currentDraw.set(currentDraw.size() - 1, next);
                renderScreen();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                int next = readEnteredNumber(entry);
                if (next < 0) return;
                if (announced.contains(next)) {
                    entry.setError("Ce numéro a déjà été annoncé.");
                    return;
                }
                acceptRecognizedNumber(next, false);
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private int readEnteredNumber(EditText entry) {
        String value = entry.getText().toString().trim();
        int next;
        try { next = Integer.parseInt(value); }
        catch (NumberFormatException ex) { next = -1; }
        if (next < 1 || next > 90) {
            entry.setError("Choisir un numéro entre 1 et 90.");
            return -1;
        }
        return next;
    }

    private void startNewDraw() {
        winnerShown = false;
        announced.clear();
        currentDraw.clear();
        lastNumberAt = -1;
        paused = false;
        pauseStartedAt = -1;
        // Le flux micro continue sans interruption.
        renderScreen();
    }

    private void confirmNewDraw() {
        new AlertDialog.Builder(this)
            .setTitle("Commencer une nouvelle partie ?")
            .setMessage("Les numéros de la partie en cours seront effacés. Aucun historique n'est conservé.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Nouvelle partie", (d, which) -> {
                startNewDraw();
            })
            .show();
    }

    private void checkMicrophonePermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            initOfflineModel();
        } else {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, RECORD_PERMISSION_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(code, permissions, grants);
        if (code == RECORD_PERMISSION_REQUEST) {
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                initOfflineModel();
            } else {
                Toast.makeText(this, "Le micro est nécessaire pour reconnaître les numéros.",
                    Toast.LENGTH_LONG).show();
                renderStatus();
            }
        }
    }

    private void initOfflineModel() {
        if (model != null || modelLoading) return;
        modelLoading = true;
        renderStatus();
        modelLoader.execute(() -> {
            try {
                File dir = installModelFromAssets();
                Model loaded = new Model(dir.getAbsolutePath());
                runOnUiThread(() -> {
                    modelLoading = false;
                    if (destroyed) {
                        loaded.close();
                        return;
                    }
                    model = loaded;
                    if (foreground) startMicrophone();
                    renderStatus();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    modelLoading = false;
                    if (!destroyed) {
                        if (statusText != null) statusText.setText("ERREUR : MODÈLE VOCAL INDISPONIBLE");
                        Toast.makeText(this, "Modèle hors ligne : " + error.getMessage(),
                            Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    /** Decompresse le modele embarque localement une seule fois, au premier lancement. */
    private File installModelFromAssets() throws IOException {
        File destination = new File(getFilesDir(), "vosk-fr");
        File marker = new File(destination, "complete.ok");
        if (marker.isFile() && new File(destination, "am/final.mdl").isFile()) return destination;
        deleteRecursive(destination);
        if (!destination.mkdirs()) throw new IOException("Impossible de créer le dossier du modèle.");
        String base = destination.getCanonicalPath() + File.separator;
        try (InputStream input = getAssets().open("model-fr.zip");
             ZipInputStream zip = new ZipInputStream(input)) {
            ZipEntry entry;
            byte[] buffer = new byte[32768];
            while ((entry = zip.getNextEntry()) != null) {
                String path = entry.getName().replace('\\', '/');
                int firstSlash = path.indexOf('/');
                if (firstSlash < 0) { zip.closeEntry(); continue; }
                String relative = path.substring(firstSlash + 1);
                if (relative.isEmpty()) { zip.closeEntry(); continue; }
                File output = new File(destination, relative);
                String canonical = output.getCanonicalPath();
                if (!canonical.startsWith(base)) throw new IOException("Chemin ZIP non valide.");
                if (entry.isDirectory()) {
                    if (!output.exists() && !output.mkdirs()) throw new IOException("Dossier non accessible.");
                } else {
                    File parent = output.getParentFile();
                    if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Dossier non accessible.");
                    try (FileOutputStream stream = new FileOutputStream(output)) {
                        int size;
                        while ((size = zip.read(buffer)) != -1) stream.write(buffer, 0, size);
                    }
                }
                zip.closeEntry();
            }
        }
        if (!new File(destination, "am/final.mdl").isFile()) {
            deleteRecursive(destination);
            throw new IOException("Fichiers du modèle incomplets.");
        }
        if (!marker.createNewFile()) throw new IOException("Marqueur modèle non créé.");
        return destination;
    }

    private void deleteRecursive(File target) {
        if (!target.exists()) return;
        if (target.isDirectory()) {
            File[] children = target.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        //noinspection ResultOfMethodCallIgnored
        target.delete();
    }

    private void startMicrophone() {
        if (!foreground || model == null || listening) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        try {
            int sampleRate = 16000;
            int minBuffer = AudioRecord.getMinBufferSize(sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int bufferSize = Math.max(minBuffer, 8192);
            AudioRecord record = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize);
            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                record.release();
                throw new IOException("Microphone non initialisé");
            }
            Recognizer recognizer = new Recognizer(model, 16000.0f);
            activeRecognizer = recognizer;
            audioRecord = record;
            listening = true;
            record.startRecording();
            microphoneThread = new Thread(() -> {
                short[] samples = new short[2048];
                byte[] pcm = new byte[samples.length * 2];
                while (listening) {
                    int count = record.read(samples, 0, samples.length);
                    if (count <= 0) continue;
                    double energy = 0;
                    for (int i = 0; i < count; i++) {
                        int value = samples[i];
                        energy += (double)value * value;
                        pcm[i * 2] = (byte)(value & 0xff);
                        pcm[i * 2 + 1] = (byte)((value >>> 8) & 0xff);
                    }
                    double rms = Math.sqrt(energy / count) / 32768.0;
                    // Affichage du signal reçu, indépendamment du seuil de reconnaissance.
                    int level = Math.min(100, (int)(Math.sqrt(rms) * 360));
                    handler.post(() -> { if (micLevel != null) micLevel.setProgress(level); });
                    try {
                        // Le curseur règle un seuil de déclenchement logiciel :
                        // à 100 %, les sons faibles sont davantage pris en compte.
                        double threshold = 0.001 + (100 - sensitivity) * 0.000045;
                        if (rms >= threshold || rms > 0.012) {
                            if (recognizer.acceptWaveForm(pcm, count * 2)) processTranscript(recognizer.getResult());
                            else onPartialResult(recognizer.getPartialResult());
                        } else {
                            // Nourrir le moteur de silence aide à terminer une phrase.
                            if (recognizer.acceptWaveForm(pcm, count * 2)) processTranscript(recognizer.getResult());
                        }
                    } catch (Exception ignored) { }
                }
            }, "LotoChrono-Microphone");
            microphoneThread.start();
        } catch (Exception error) {
            stopMicrophone();
            Toast.makeText(this, "Micro : " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
        renderStatus();
    }

    private void stopMicrophone() {
        listening = false;
        AudioRecord record = audioRecord;
        audioRecord = null;
        if (record != null) {
            try { record.stop(); } catch (Exception ignored) { }
        }
        Thread worker = microphoneThread;
        microphoneThread = null;
        if (worker != null && worker != Thread.currentThread()) {
            try { worker.join(600); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        }
        if (record != null) record.release();
        if (activeRecognizer != null) {
            activeRecognizer.close();
            activeRecognizer = null;
        }
        if (micLevel != null) micLevel.setProgress(0);
        renderStatus();
    }

    private void renderStatus() {
        if (statusText == null) return;
        if (modelLoading) statusText.setText("● CHARGEMENT DU FRANÇAIS HORS LIGNE...");
        else if (listening) statusText.setText("● MICRO ACTIF · HORS LIGNE");
        else if (model != null) statusText.setText("● MICRO EN PAUSE");
        else statusText.setText("● MICRO NON DISPONIBLE");
    }

    /** La reconnaissance finale est traitee, les resultats partiels ne changent jamais le timer. */
    @Override public void onResult(String json) { processTranscript(json); }
    @Override public void onFinalResult(String json) { processTranscript(json); }
    @Override public void onPartialResult(String json) {
        try {
            String spoken = new JSONObject(json).optString("partial", "");
            if (spoken.isEmpty()) return;
            if (SpeechCommandParser.isWinnerCommand(spoken) || SpeechCommandParser.isFalseWinnerCommand(spoken)) {
                processTranscript(new JSONObject().put("text", spoken).toString());
            }
        } catch (Exception ignored) { }
    }
    @Override public void onTimeout() { /* Ecoute sans limite de duree. */ }
    @Override public void onError(Exception error) {
        runOnUiThread(() -> {
            if (foreground && !destroyed) {
                Toast.makeText(this, "Reconnaissance : " + error.getMessage(), Toast.LENGTH_LONG).show();
                stopMicrophone();
                handler.postDelayed(this::startMicrophone, 1000);
            }
        });
    }

    private void processTranscript(String json) {
        if (destroyed) return;
        try {
            String spoken = new JSONObject(json).optString("text", "");
            boolean winner = SpeechCommandParser.isWinnerCommand(spoken);
            boolean falseWinner = SpeechCommandParser.isFalseWinnerCommand(spoken);
            int parsed = winner || falseWinner ? -1 : FrenchNumberParser.parse(spoken);
            if (!winner && !falseWinner && parsed < 1) return;
            runOnUiThread(() -> {
                if (!foreground || destroyed) return;
                long now = SystemClock.elapsedRealtime();
                if (winnerShown) {
                    if (SpeechCommandParser.isFalseWinnerCommand(spoken) && now - lastVoiceCommandAt > 1000) {
                        lastVoiceCommandAt = now;
                        winnerShown = false;
                        setPaused(false);
                        renderScreen();
                    }
                } else if (winner && now - lastVoiceCommandAt > 1000) {
                    lastVoiceCommandAt = now;
                    winnerShown = true;
                    setPaused(true);
                    renderScreen();
                } else if (!paused) acceptRecognizedNumber(parsed, true);
            });
        } catch (Exception ignored) {
            // Resultat vocal non numerique ou JSON incomplet : ignore.
        }
    }

    @Override protected void onStart() {
        super.onStart();
        foreground = true;
        if (model != null) startMicrophone();
    }

    @Override protected void onStop() {
        foreground = false;
        stopMicrophone();
        super.onStop();
    }

    @Override protected void onDestroy() {
        destroyed = true;
        stopMicrophone();
        handler.removeCallbacksAndMessages(null);
        modelLoader.shutdown();
        if (model != null) {
            model.close();
            model = null;
        }
        super.onDestroy();
    }
}
