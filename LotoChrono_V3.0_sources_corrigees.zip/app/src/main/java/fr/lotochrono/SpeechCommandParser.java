package fr.lotochrono;

/** Commandes vocales du loto : annonce et annulation d'un gagnant. */
public final class SpeechCommandParser {
    private SpeechCommandParser() { }

    public static boolean isFalseWinnerCommand(String transcript) {
        if (transcript == null) return false;
        String text = " " + FrenchNumberParser.normalize(transcript) + " ";
        return text.contains(" il s est trompe ")
            || text.contains(" elle s est trompee ")
            || text.contains(" elle s est trompe ")
            || text.contains(" c est une erreur ");
    }

    public static boolean isWinnerCommand(String transcript) {
        if (transcript == null || isFalseWinnerCommand(transcript)) return false;
        String text = " " + FrenchNumberParser.normalize(transcript) + " ";
        return text.contains(" gagnant ") || text.contains(" gagnante ");
    }
}
