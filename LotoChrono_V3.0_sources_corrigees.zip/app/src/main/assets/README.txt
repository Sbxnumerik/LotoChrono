Le fichier model-fr.zip est telecharge automatiquement pendant la compilation
par la tache Gradle prepareOfflineModel. Il est embarque dans l'APK.
Aucune permission Internet n'est declaree pour l'application Android.
